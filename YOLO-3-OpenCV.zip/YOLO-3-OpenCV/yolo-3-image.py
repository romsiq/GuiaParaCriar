"""
Guia para Criar
www.guiaparacriar.com.br
https://github.com/romsiq/GuiaParaCriar

Introdução: YOLO v3 para Detectar Objetos em Imagem
Arquivo: yolo-3-image.py
"""

# Importando as bibliotecas necessárias
import numpy as np
import cv2
import time


"""
Iniciando a leitura da imagem que gostaria de usar para detectar objetos.
"""

# Leitura de imagem com biblioteca OpenCV
# Desta forma, a imagem já é aberta como um array numpy
# ATENÇÃO! OpenCV por padrão lê imagens no formato BGR

image_BGR = cv2.imread('images/foto_cachorro.jpg')

# Mostrando imagem original
# Dar nome à janela com imagem original
# E especificar que a janela é redimensionável

cv2.namedWindow('Imagem Original', cv2.WINDOW_NORMAL)
cv2.imshow('Imagem Original', image_BGR)
# Esperando que qualquer tecla seja pressionada
cv2.waitKey(0)
# Destruindo a janela aberta com o nome 'Imagem Original'
cv2.destroyWindow('Imagem Original')

# Obtendo a dimensão espacial da imagem de entrada
# Corte da tupla apenas os dois primeiros elementos
h, w = image_BGR.shape[:2]

"""
Fim da leitura da imagem que gostaria de usar para detectar objetos.
"""


"""
Iniciando coleta de entrada sobre a função blob.
"""

blob = cv2.dnn.blobFromImage(image_BGR, 1 / 255.0, (416, 416),
                             swapRB=True, crop=False)

"""
Fim da coleta de entrada sobre a função blob.
"""

"""
Iniciando o carregamento da rede Yolo v3.
"""

# Carregando rótulos de classe COCO do arquivo
# Abrindo arquivo
with open('yolo-coco-data/coco.names') as f:
    # Obtendo rótulos lendo cada linha
    # e colocá-los na lista
    labels = [line.strip() for line in f]

# Carregando detector de objetos YOLO v3 treinado
# com a ajuda da biblioteca 'dnn' da OpenCV
network = cv2.dnn.readNetFromDarknet('yolo-coco-data/yolov3.cfg',
                                     'yolo-coco-data/yolov3.weights')

# Obtendo lista com nomes de todas as camadas da rede YOLO v3
layers_names_all = network.getLayerNames()

# Obtendo apenas os nomes das camadas de saída que precisamos do algoritmo YOLO v3
# com função que retorna índices de camadas com saídas não conectadas
layers_names_output = \
    [layers_names_all[i[0] - 1] for i in network.getUnconnectedOutLayers()]

# Definir probabilidade mínima para eliminar previsões fracas
probability_minimum = 0.5

# Definir o limite para filtrar caixas delimitadoras fracas
threshold = 0.3

# Gerar cores para representar cada objeto detectado
colours = np.random.randint(0, 255, size=(len(labels), 3), dtype='uint8')


"""
Fim do carregamento da rede Yolo v3.
"""


"""
Iniciando passagem para frente com nosso blob e apenas através das camadas de saída.
"""

network.setInput(blob)
start = time.time()
output_from_network = network.forward(layers_names_output)
end = time.time()

# Mostrando tempo gasto para passe para frente
print('Detecção de Objetos levou {:.5f} segundos'.format(end - start))

"""
Fim passagem para frente com nosso blob e apenas através das camadas de saída.
"""


"""
Inicio Obtendo caixas delimitadoras
"""

# Preparar lista para detectar caixas
bounding_boxes = []
confidences = []
class_numbers = []

# Percorrer todas as camadas de saída após a passagem de feed forward
for result in output_from_network:
    # Percorrer todas as detecções da camada de saída atual
    for detected_objects in result:
        # Obtendo probabilidades de 80 classes para o objeto detectado atual
        scores = detected_objects[5:]
        # Obtendo índice da classe com o valor máximo de probabilidade
        class_current = np.argmax(scores)
        # Obtendo valor de probabilidade para classe definida
        confidence_current = scores[class_current]

        # Eliminar previsões fracas com probabilidade mínima
        if confidence_current > probability_minimum:
            box_current = detected_objects[0:4] * np.array([w, h, w, h])
            x_center, y_center, box_width, box_height = box_current
            x_min = int(x_center - (box_width / 2))
            y_min = int(y_center - (box_height / 2))

            # Adicionar resultados em listas preparadas
            bounding_boxes.append([x_min, y_min, int(box_width), int(box_height)])
            confidences.append(float(confidence_current))
            class_numbers.append(class_current)

"""
Fim Obtendo caixas delimitadoras
"""


"""
Iniciando Supressão não máxima
"""

# Implementar supressão não máxima de determinadas caixas delimitadoras
# Com esta técnica, excluímos algumas das caixas delimitadoras se seus
# confidências correspondentes são baixas ou há outra
# caixa delimitadora para esta região com maior confiança

# É necessário certificar-se de que o tipo de dados das caixas é 'int'
# e o tipo de dados das confidências é 'float'
# https://github.com/opencv/opencv/issues/12789

results = cv2.dnn.NMSBoxes(bounding_boxes, confidences,
                           probability_minimum, threshold)

"""
Fim Supressão não máxima
"""


"""
Iniciando Desenho de caixas delimitadoras e rótulos
"""

# Definir contador para objetos detectados
counter = 1

# Verificar se há pelo menos um objeto detectado após a supressão não máxima
if len(results) > 0:
    # Percorrer índices de resultados
    for i in results.flatten():
        # Mostrando rótulos dos objetos detectados
        print('Object {0}: {1}'.format(counter, labels[int(class_numbers[i])]))

        # Contador de incremento
        counter += 1

        # Obtendo as coordenadas atuais da caixa delimitadora,
        # sua largura e altura
        x_min, y_min = bounding_boxes[i][0], bounding_boxes[i][1]
        box_width, box_height = bounding_boxes[i][2], bounding_boxes[i][3]

        # Preparando a cor para a caixa delimitadora atual
        # e convertendo de numpy array para list
        colour_box_current = colours[class_numbers[i]].tolist()

        # Desenho de caixa delimitadora na imagem original
        cv2.rectangle(image_BGR, (x_min, y_min),
                      (x_min + box_width, y_min + box_height),
                      colour_box_current, 2)

        # Preparando texto com rótulo e confiança para a caixa delimitadora atual
        text_box_current = '{}: {:.4f}'.format(labels[int(class_numbers[i])],
                                               confidences[i])

        # Colocar texto com etiqueta e confiança na imagem original
        cv2.putText(image_BGR, text_box_current, (x_min, y_min - 5),
                    cv2.FONT_HERSHEY_COMPLEX, 0.7, colour_box_current, 2)

# Comparando quantos objetos estavam antes da supressão não máxima
# e saiu depois
print()
print('Total de objetos detectados:', len(bounding_boxes))
print('Número de objetos restantes após a supressão não máxima:', counter - 1)

"""
Fim Desenho de caixas delimitadoras e rótulos
"""

# Mostrando a imagem original com objetos detectados
# Dar nome à janela com imagem original
cv2.namedWindow('Detecções', cv2.WINDOW_NORMAL)
cv2.imshow('Detecções', image_BGR)
# Esperando que qualquer tecla seja pressionada
cv2.waitKey(0)
# Destruindo a janela aberta com o nome 'Detecções
cv2.destroyWindow('Detecções')
