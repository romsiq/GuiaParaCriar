"""
Guia para Criar
www.guiaparacriar.com.br
https://github.com/romsiq/GuiaParaCriar

Introdução: YOLO v3 para Detectar Objetos por Câmera
Arquivo: yolo-3-camera.py
"""

# Detecta Objetos e Tempo Real usando OpenCV
#

# Importando as bibliotecas necessárias
import numpy as np
import cv2
import time


"""
Iniciando a leitura de streaming de video da câmera.
"""
camera = cv2.VideoCapture(0)

# Preparação de variáveis ​​para dimensões dos frames
h, w = None, None


"""
Carregando YOLO v3 network
"""
# Carregando rótulos (Labels) de classe COCO
# Abrindo arquivo coco.names

with open('yolo-coco-data/coco.names') as f:
    # Coletando os rótulos para cada linha e colocando em uma lista.
    labels = [line.strip() for line in f]


# Carregando o modelo treinado do YOLO v3 para detecção de objetos.
# aqui utilizamos a rede dnn e frameword Darknet.
# o arquivo yolov3.cfg contém todas as configurações e parâmetros necessários para o treino e teste.
# o arquivo yolov3.weights contém todos os pesos do modelo treinado.
network = cv2.dnn.readNetFromDarknet('yolo-coco-data/yolov3.cfg',
                                     'yolo-coco-data/yolov3.weights')

# Obtendo lista com nomes de todas as camadas da rede YOLO v3
layers_names_all = network.getLayerNames()


# Obtendo apenas os nomes das camadas de saída que precisamos do algoritmo YOLO v3
# com função que retorna índices de camadas com saídas não conectadas
layers_names_output = \
    [layers_names_all[i[0] - 1] for i in network.getUnconnectedOutLayers()]


# Definir probabilidade mínima para eliminar previsões fracas
probability_minimum = 0.5

# Definir o limite para filtrar caixas delimitadoras fracas
threshold = 0.3

# Gerar cores para representar cada objeto detectado
# function randint(low, high=None, size=None, dtype='l')
colours = np.random.randint(0, 255, size=(len(labels), 3), dtype='uint8')


"""
Fim da etapa de carregamento da rede YOLO v3

"""


"""
Inicio da leitura de frames (em loop) 
"""

# Definindo looping para captura de frames
while True:
    # capturando frame por frame na camera.
    _, frame = camera.read()

    # Coletando a dimenção do frame, coleta-se apenas uma vez,
    # pois os demais frames seguem o mesmo tamanho.
    if w is None or h is None:
        # Divide em tupla somente os primeiros 2 elementos.
        h, w = frame.shape[:2]

    """
    Inicio, obtendo quadro atual - frame
    """

    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416),
                                 swapRB=True, crop=False)
    """
    Fim. quadro atual - frame
    """

    """
    Inicio: Implementação de passagem através de camadas de saída. 
    """

    network.setInput(blob)
    start = time.time()
    output_from_network = network.forward(layers_names_output)
    end = time.time()

    # Apresenta o tempo gasto pelo frame atual
    print('Current frame took {:.5f} seconds'.format(end - start))

    """
    Fim: Implementação de passagem através de camadas de saída. 
    """

    """
    Início: Preparando listas para caixas delimitadoras detectadas, número de classes.
    """

    bounding_boxes = []
    confidences = []
    class_numbers = []

    # Percorrer todas as camadas de saída após a passagem de feed forward
    for result in output_from_network:
        # Percorrer todas as detecções da camada de saída atual
        for detected_objects in result:
            # Obtendo probabilidades de 80 classes para o objeto detectado atual
            scores = detected_objects[5:]
            # Obtendo índice da classe com o valor máximo de probabilidade
            class_current = np.argmax(scores)
            # Obtendo valor de probabilidade para classe definida
            confidence_current = scores[class_current]

            # Eliminar previsões fracas com probabilidade mínima
            if confidence_current > probability_minimum:
                box_current = detected_objects[0:4] * np.array([w, h, w, h])
                # Agora, a partir do formato de dados YOLO, podemos obter as coordenadas do canto superior esquerdo
                # que são x_min e y_min
                x_center, y_center, box_width, box_height = box_current
                x_min = int(x_center - (box_width / 2))
                y_min = int(y_center - (box_height / 2))

                # Adicionando os resultados em uma lista
                bounding_boxes.append([x_min, y_min,
                                       int(box_width), int(box_height)])
                confidences.append(float(confidence_current))
                class_numbers.append(class_current)

    """
    Fim: Preparando listas para caixas delimitadoras detectadas, número de classes.
    """

    """
    Inicio: Implementar supressão não máxima de determinadas caixas delimitadoras.
    """

    # Com esta técnica, excluímos algumas das caixas delimitadoras se seus
    # confidências correspondentes são baixas ou há outra
    # caixa delimitadora para esta região com maior confiança
    # É necessário certificar-se de que o tipo de dados das caixas é 'int'
    # e o tipo de dados das confidências é 'float'.
    # https://github.com/opencv/opencv/issues/12789

    results = cv2.dnn.NMSBoxes(bounding_boxes, confidences,
                               probability_minimum, threshold)

    """
    Fim: Implementar supressão não máxima de determinadas caixas delimitadoras.
    """

    """
    Início: Desenho de caixas delimitadoras e rótulos. 
    """

    # Verificando se há pelo menos um objeto detectado
    # após supressão não máxima

    if len(results) > 0:
        # Analisando índices de resultados
        for i in results.flatten():
            # Obtendo as coordenadas atuais da caixa delimitadora,
            # sua largura e altura
            x_min, y_min = bounding_boxes[i][0], bounding_boxes[i][1]
            box_width, box_height = bounding_boxes[i][2], bounding_boxes[i][3]

            # Preparando a cor para a caixa delimitadora atual
            # e convertendo de numpy array para list
            colour_box_current = colours[class_numbers[i]].tolist()

            # Desenho de caixa delimitadora no quadro atual original
            cv2.rectangle(frame, (x_min, y_min),
                          (x_min + box_width, y_min + box_height),
                          colour_box_current, 2)

            # Preparando texto com rótulo e confiança para a caixa delimitadora atual
            text_box_current = '{}: {:.4f}'.format(labels[int(class_numbers[i])],
                                                   confidences[i])

            # Colocar texto com etiqueta e confiança na imagem original
            cv2.putText(frame, text_box_current, (x_min, y_min - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour_box_current, 2)

    """
    Fim: Desenho de caixas delimitadoras e rótulos.
    """

    """
    Inicio: Mostrando frames processados ​​na janela OpenCV
    """

    # Mostrando quadro atual com objetos detectados
    # Dar nome à janela com o quadro atual
    # E especificar que a janela é redimensionável
    cv2.namedWindow('YOLO v3 Detecção em Tempo Real', cv2.WINDOW_NORMAL)
    cv2.imshow('YOLO v3 Detecção em Tempo Real', frame)

    # Quebrando o loop se 'q' for pressionado
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    """
    Fim: Mostrando frames processados ​​na janela OpenCV
    """

"""
Fim da leitura de frames (em loop)
"""


# Liberando camera
camera.release()
# Destruindo todas as janelas abertas do OpenCV
cv2.destroyAllWindows()


"""
Atenção: cv2.VideoCapture (0)

Para capturar o vídeo, é necessário criar o objeto VideoCapture.
Seu argumento pode ser o índice da câmera ou o nome do arquivo de vídeo.
O índice da câmera é geralmente 0 para câmeras integradas.
Tente selecionar outras câmeras passando os valores 1, 2, 3, etc.
"""
