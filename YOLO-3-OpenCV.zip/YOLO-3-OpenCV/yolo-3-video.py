"""
Guia para Criar
www.guiaparacriar.com.br
https://github.com/romsiq/GuiaParaCriar

Introdução: YOLO v3 para Detectar Objetos em arquivos de Videos
Arquivo: yolo-3-video.py
"""

# Importando as bibliotecas necessárias
import numpy as np
import cv2
import time


"""
Inicio Leitura de entrada de vídeo
"""
# Definindo o objeto 'VideoCapture'
# e lendo o vídeo de um arquivo
video = cv2.VideoCapture('videos/arquivo_video_que_gostaria_detectar_objetos.mp4')

# Preparando variável para escritor
# que usaremos para escrever frames processados
writer = None

# Preparação de variáveis ​​para dimensões espaciais dos frames
h, w = None, None

"""
Fim Leitura de entrada de vídeo
"""


"""
Carregando YOLO v3 network
"""

# Carregando rótulos de classe COCO do arquivo
# Abrindo arquivo
with open('yolo-coco-data/coco.names') as f:
    # Obtendo rótulos lendo cada linha
    # e colocá-los na lista
    labels = [line.strip() for line in f]


# Carregando detector de objetos YOLO v3 treinado
# com a ajuda da biblioteca 'dnn' da OpenCV
network = cv2.dnn.readNetFromDarknet('yolo-coco-data/yolov3.cfg',
                                     'yolo-coco-data/yolov3.weights')

# Obtendo lista com nomes de todas as camadas da rede YOLO v3
layers_names_all = network.getLayerNames()

# Obtendo apenas os nomes das camadas de saída que precisamos do algoritmo YOLO v3
# com função que retorna índices de camadas com saídas não conectadas
layers_names_output = \
    [layers_names_all[i[0] - 1] for i in network.getUnconnectedOutLayers()]

# Definir probabilidade mínima para eliminar previsões fracas
probability_minimum = 0.5

# Definir o limite para filtrar caixas delimitadoras fracas
threshold = 0.3

# Gerar cores para representar cada objeto detectado
colours = np.random.randint(0, 255, size=(len(labels), 3), dtype='uint8')


"""
Fim da etapa de carregamento da rede YOLO v3
"""


"""
Inicio da leitura de frames (em loop) 
"""

# Definindo variável para contagem de quadros
# No final mostraremos a quantidade total de frames processados
f = 0

# Definindo variável para contagem de tempo total
# No final iremos mostrar o tempo gasto para processar todos os frames
t = 0

# Definição de loop para captura de quadros
while True:
    # Capturando quadro a quadro
    ret, frame = video.read()

    # Se o quadro não foi recuperado
    # por exemplo: no final do vídeo,
    # então quebramos o ciclo
    if not ret:
        break

    # Obtendo as dimensões espaciais do quadro
    # fazemos isso apenas uma vez desde o início
    # todos os outros quadros têm a mesma dimensão
    if w is None or h is None:
        # Corte da tupla apenas os dois primeiros elementos
        h, w = frame.shape[:2]

    """
    Coletando blob do frame atual
    """

    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416),
                                 swapRB=True, crop=False)

    """
    Fim da coleta de blob do frame atual
    """

    """
    Implementando passe para frente
    """

    # Implementação de passagem para frente com nosso blob e apenas através das camadas de saída
    # Calculando ao mesmo tempo, o tempo necessário para o passe para frente
    network.setInput(blob)
    start = time.time()
    output_from_network = network.forward(layers_names_output)
    end = time.time()

    # Contadores crescentes para frames e tempo total
    f += 1
    t += end - start

    # Mostrando o tempo gasto para um único quadro atual
    print('Frame numero {0} levou {1:.5f} segundos'.format(f, end - start))

    """
    Fim passe para frente
    """

    """
    Inicio Obtendo caixas delimitadoras
    """

    # Preparando listas para caixas delimitadoras detectadas,
    # confidências obtidas e número da classe
    bounding_boxes = []
    confidences = []
    class_numbers = []

    # Percorrer todas as camadas de saída após a passagem de feed forward
    for result in output_from_network:
        # Percorrer todas as detecções da camada de saída atual
        for detected_objects in result:
            # Obtendo probabilidades de 80 classes para o objeto detectado atual
            scores = detected_objects[5:]
            # Obtendo índice da classe com o valor máximo de probabilidade
            class_current = np.argmax(scores)
            # Obtendo valor de probabilidade para classe definida
            confidence_current = scores[class_current]

            # Eliminar previsões fracas com probabilidade mínima
            if confidence_current > probability_minimum:
                box_current = detected_objects[0:4] * np.array([w, h, w, h])
                # Podemos obter as coordenadas do canto superior esquerdo
                # que são x_min e y_min
                x_center, y_center, box_width, box_height = box_current
                x_min = int(x_center - (box_width / 2))
                y_min = int(y_center - (box_height / 2))

                # Adicionar resultados em listas preparadas
                bounding_boxes.append([x_min, y_min,
                                       int(box_width), int(box_height)])
                confidences.append(float(confidence_current))
                class_numbers.append(class_current)

    """
    Fim Obtendo caixas delimitadoras
    """

    """
    Iniciando Supressão não máxima
    """

    # Implementar supressão não máxima de determinadas caixas delimitadoras
    # Com esta técnica, excluímos algumas das caixas delimitadoras se seus
    # confidências correspondentes são baixas ou há outra
    # caixa delimitadora para esta região com maior confiança

    # É necessário certificar-se de que o tipo de dados das caixas é 'int'
    # e o tipo de dados das confidências é 'float'
    # https://github.com/opencv/opencv/issues/12789
    results = cv2.dnn.NMSBoxes(bounding_boxes, confidences,
                               probability_minimum, threshold)

    """
    Fim Supressão não máxima
    """

    """
    Inicio Desenho de caixas delimitadoras e rótulos
    """

    # Verificando se há pelo menos um objeto detectado
    if len(results) > 0:
        # Percorrer índices de resultados
        for i in results.flatten():
            # Obtendo as coordenadas atuais da caixa delimitadora,
            # sua largura e altura
            x_min, y_min = bounding_boxes[i][0], bounding_boxes[i][1]
            box_width, box_height = bounding_boxes[i][2], bounding_boxes[i][3]

            # Preparando a cor para a caixa delimitadora atual
            # e convertendo de numpy array para list
            colour_box_current = colours[class_numbers[i]].tolist()

            # Desenho de caixa delimitadora no quadro atual original
            cv2.rectangle(frame, (x_min, y_min),
                          (x_min + box_width, y_min + box_height),
                          colour_box_current, 2)

            # Preparando texto com rótulo e confiança para a caixa delimitadora atual
            text_box_current = '{}: {:.4f}'.format(labels[int(class_numbers[i])],
                                                   confidences[i])

            # Colocar texto com etiqueta e confiança na imagem original
            cv2.putText(frame, text_box_current, (x_min, y_min - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour_box_current, 2)

    """
    Fim Desenho de caixas delimitadoras e rótulos
    """

    """
    Inicio Gravando frame processado no arquivo
    """

    # Inicializando o escritor
    # fazemos isso apenas uma vez desde o início
    # quando obtemos as dimensões espaciais dos frames
    if writer is None:
        # Construindo o código do codec
        # para ser usado na função VideoWriter
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')

        writer = cv2.VideoWriter('videos/resultado_em_video.mp4', fourcc, 30,
                                 (frame.shape[1], frame.shape[0]), True)

    # Grava o quadro atual processado no arquivo
    writer.write(frame)

    """
    Fim Gravando frame processado no arquivo
    """

"""
Fim Lendo frames no loop
"""


# Apresentando o resultado final
print()
print('Número total de frames', f)
print('Tempo total {:.5f} segundos'.format(t))
print('FPS:', round((f / t), 1))


# Liberando leitor e escritor de vídeo
video.release()
writer.release()


"""
Parâmetros para cv2.VideoWriter ():
    filename - Nome do arquivo de vídeo de saída.
    fourcc - código de codec de 4 caracteres usado para compactar os quadros.
    fps - Taxa de quadros do vídeo criado.
    frameSize - Tamanho dos quadros de vídeo.
    isColor - Se for True, o codificador esperará e codificará quadros de cores.
"""
